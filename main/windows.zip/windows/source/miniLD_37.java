import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class miniLD_37 extends PApplet {

int buttonX = 200;
int buttonY = 150;
int textcounter = 0;
int bg = 0;

String textval = "click the button to make a 'click' noise";
String abouttext = "Made in under 3 minutes by Gallefray for the mini Ludum Dare #37 \n http://gallefray.github.com/index.html";

public void setup() {
  size(400, 400);
}

public void draw() {
  //BACKGROUND COLOUR
  //set to black
  background(bg);

  //BIG RED BUTTON
  //set the ellipse' colour to red
  fill(255, 0, 0);
  ellipse(buttonX, buttonY, 75, 75);

  //text elements
  PFont myFont;
  myFont = loadFont("Calibri-48.vlw"); //Calibri-48.vlw
  textFont(myFont, 20);
  textAlign(CENTER);
  fill(255);
  text(textval, width/2, height/1.60f);
  textFont(myFont, 14);
  text(abouttext, width/2, height/1.25f); 
}



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ECE9D8", "miniLD_37" });
  }
}
